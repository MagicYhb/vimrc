# Setup fzf
# ---------
if [[ ! "$PATH" == */home/yhb/.fzf/bin* ]]; then
  export PATH="${PATH:+${PATH}:}/home/yhb/.fzf/bin"
fi

# Auto-completion
# ---------------
[[ $- == *i* ]] && source "/home/yhb/.fzf/shell/completion.bash" 2> /dev/null

# Key bindings
# ------------
source "/home/yhb/.fzf/shell/key-bindings.bash"
